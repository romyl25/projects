#include <fstream>
#include <iostream>
#include <string>

#include "GroceryItem.hpp"
#include "GroceryList.hpp"

using namespace std;

int main(int argc, char* argv[])
{
  ifstream ifile("ShoppingList2.txt");

  GroceryList shopping;
  GroceryItem temp;
  
  ifile >> temp;
 
  while (ifile)
    {
      shopping+=temp;

      ifile>>temp;
    }

  ifile.close();

  shopping.checkOff("Robot");
  cout << "===Robot should be PURCHASED in the list:===" << endl
       << shopping;

  cout << "The following should not cause a crash:" << endl;
  shopping.checkOff("PowerballWinner");
  cout << "Good - it did not crash!"  << endl;

  return 0;
}
