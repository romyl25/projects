#include <iostream>

#include "GroceryItem.hpp"
#include "GroceryList.hpp"

using namespace std;

int main(int argc, char* argv[])
{
  GroceryList shopping;

  cout << "This should be zero:" << shopping.getLength() << endl;

  cout << "There should be nothing between the two ============= lines!"
       << endl
       << "====================" << endl
       << shopping
       << "====================" << endl;
  
  GroceryItem cookies("Oreos", 4);
  
  shopping+=cookies;

  cout << "There should be only oreos (4)  between the two ============= lines!"
       << endl
       << "====================" << endl
       << shopping
       << "====================" << endl;

  cout << "This should be one:" << shopping.getLength() << endl;

  GroceryItem candy("Halloween Candy", 137);
  
  shopping+=candy;

  cout << "There should be only oreos and halloween candy between the =========== lines!"
       << endl
       << "====================" << endl
       << shopping
       << "====================" << endl;

  cout << "This should be two:" << shopping.getLength() << endl;

  
  return 0;
}
