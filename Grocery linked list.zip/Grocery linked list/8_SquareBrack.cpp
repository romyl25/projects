#include <fstream>
#include <iostream>
#include <string>

#include "GroceryItem.hpp"
#include "GroceryList.hpp"

using namespace std;

void performLookup(const GroceryList &gl, const string &item)
{
  GroceryItem *ptr = gl[item];
  if (ptr!=NULL)
  { 
    cout << "Found: " << *ptr << endl;
  }
  else
  {
    cout << "Sorry, " << item << " was not found." << endl;
  }
}
int main(int argc, char* argv[])
{
  ifstream ifile("ShoppingList2.txt");

  GroceryList shopping;
  GroceryItem temp;
  
  ifile >> temp;
 
  while (ifile)
    {
      shopping+=temp;

      ifile>>temp;
    }

  ifile.close();

  performLookup(shopping, "Robot");
  performLookup(shopping, "Klingon");

  shopping["Robot"]->name() = "Android";
  cout << "===Robot should be replaced with Android in the list:===" << endl
       << shopping;

  return 0;
}
