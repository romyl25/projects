#include <iostream>

#include "GroceryItem.hpp"
#include "GroceryList.hpp"

using namespace std;

int main(int argc, char* argv[])
{
  GroceryList shopping;

  GroceryItem cookies("Oreos", 4);
  
  shopping+=cookies;

  GroceryItem candy("Halloween Candy", 137);
  
  shopping+=candy;


  GroceryList copy, copy2;

  copy2=copy=shopping; 

  GroceryItem copyAdd("Celery" , 1);

  copy += copyAdd;
  
  cout << "oreos, halloween candy, and celery between the =========== lines!"
       << endl
       << "====================" << endl
       << copy
       << "====================" << endl;

  cout << "This should be three:" << copy.getLength() << endl;

  copyAdd.name()="Ranch";
  copyAdd.quantity() =2;
  
  cout << "oreos, halloween candy, ranch between the =========== lines!"
       << endl
       << "====================" << endl
       <<   (copy2+=copyAdd)
       << "====================" << endl;

  cout << "This should be three:" << copy2.getLength() << endl;

  
  return 0;
}
