#include <fstream>
#include <iostream>
#include <string>

#include "GroceryItem.hpp"
#include "GroceryList.hpp"

using namespace std;

int main(int argc, char* argv[])
{
  ifstream ifile("ShoppingList2.txt");

  GroceryList shopping;
  GroceryItem temp;
  
  ifile >> temp;
 
  while (ifile)
    {
      shopping+=temp;

      ifile>>temp;
    }

  ifile.close();

  
  cout << "Number of items in list BEFORE removing Robot: "
       << shopping.getLength()<<endl;

  shopping-="Robot";

  cout << "Number of items in list AFTER removing Robot: "
       << shopping.getLength()<<endl;

  shopping-="Klingon";
  
  cout << "Number of items in list AFTER removing Klingon: "
       << shopping.getLength()<<endl;

  return 0;
}
