#include <iostream>

#include "GroceryItem.hpp"
#include "GroceryList.hpp"

using namespace std;

int main(int argc, char* argv[])
{
  GroceryList shopping;

  cout << "This should be zero:" << shopping.getLength() << endl;
  
  return 0;
}
