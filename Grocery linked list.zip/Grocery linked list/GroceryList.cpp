/********************************************
 * Romyal Swarnkar                          *
 * 11/13/2021                           *
 * Computer Science 2                       *
 * Programming Project 3                    *
 ********************************************/

#include "GroceryList.hpp"

GroceryList::GroceryList() { this->head = NULL; }

int GroceryList::getLength() const {
  int count = 0;
  GroceryItem *temp;
  temp = this->head;
  while (temp) {
    temp = temp->next;
    count++;
  }
  return count;
}

GroceryList GroceryList::operator=(const GroceryList li) {
  // set head for current list to nullptr
  this->head = NULL;
  GroceryItem *temp = li.head;
  GroceryItem *temp2;
  // for each item in the list on RHS, create a duplicate and link to this list.
  while (temp != NULL) {
    GroceryItem *item = new GroceryItem(temp->name(), temp->quantity());
    if (temp->bought()) {
      item->bought() = true;
    }
    // Initially when head will be NULL, update the head to point to first item.
    if (!head) {
      head = item;
      temp2 = head;
    }
    // keep chaining the new items to form singly linked list.
    else {
      temp2->next = item;
      temp2 = temp2->next;
    }
    temp = temp->next;
  }
  return *this;
}

GroceryList GroceryList::operator+=(const GroceryItem &item) {
  // create a copy
  GroceryItem *temp = this->head;
  GroceryItem *newItem = new GroceryItem(item.name(), item.quantity());
  if (item.bought()) {
    newItem->bought() = true;
  }

  // If the groceryList is empty, then just add the item to the list.
  if (!temp) {
    this->head = newItem;
    return *this;
  }

  // check if the item is already present in the list.
  // if so, just update the quantity
  while (temp->next != NULL) {
    if (temp->name() == item.name()) {
      temp->quantity() += item.quantity();
      return *this;
    }
    temp = temp->next;
  }
  if (temp->name() == item.name()) {
    temp->quantity() += item.quantity();
    return *this;
  }

  // item is not present.
  // add the item to the end of the list.
  temp->next = newItem;
  return *this;
}

GroceryList GroceryList::operator+=(const GroceryList &li) {
  GroceryItem *temphead = li.head;
  // For each item in this list, use += overloaded operator for GroceryItem
  while (temphead != NULL) {
    *this += *temphead;
    temphead = temphead->next;
  }
  return *this;
}

GroceryList GroceryList::operator-=(const std::string &name) {
  // use two pointers, previous and current
  GroceryItem *previous, *current;
  previous = NULL;
  current = this->head;
  while (current != NULL) {
    // if match found, just break from here.
    if (current->name() == name) {
      break;
    }
    previous = current;
    current = current->next;
  }
  // delete the item and free up the memory if found.
  if (current) {
    GroceryItem *itemToDelete = current;
    previous->next = current->next;
    free(itemToDelete);
  }
  return *this;
}

GroceryItem *GroceryList::operator[](const std::string &name) const {
  GroceryItem *temp = this->head;
  // scan the linked list.
  while (temp != NULL) {
    // If match found
    if (temp->name() == name) {
      return temp;
    }
    temp = temp->next;
  }
  // no match found
  return NULL;
}

void GroceryList::checkOff(const std::string &name) {
  GroceryItem *temp = this->head;
  // scan the linked list.
  while (temp != NULL) {
    // if match found, update.
    if (temp->name() == name) {
      temp->bought() = true;
      break;
    }
    temp = temp->next;
  }
}

std::ostream &operator<<(std::ostream &os, const GroceryList &li) {
  GroceryItem *temp = li.head;
  while (temp) {
    os << *temp << "\n";
    temp = temp->next;
  }
  return os;
}