
#include <iostream>

#include "GroceryItem.hpp"
#include "GroceryList.hpp"

using namespace std;

int main(int argc, char* argv[])
{
  GroceryList shopping;

  GroceryItem cookies("Oreos", 4);
  
  shopping+=cookies;

  GroceryItem candy("Halloween Candy", 137);
  
  shopping+=candy;
  shopping+=candy;

  cout << "There should be 274 Halloween Candy and 4 Oreos in this list:"
       << endl
       << "================================="
       << endl
       << shopping
           << "================================="
       << endl;
  
  cout << "This should be two:" << shopping.getLength() << endl;

  GroceryItem moreOreos("Oreos", 2);
  shopping+=moreOreos;
  
  cout << "There should be 274 Halloween Candy and 6 Oreos in this list:"
       << endl
       << "================================="
       << endl
       << shopping
           << "================================="
       << endl;

  cout << "This should be two:" << shopping.getLength() << endl;
    
  return 0;
}
