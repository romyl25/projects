#include <fstream>
#include <iostream>
#include <string>

#include "GroceryItem.hpp"
#include "GroceryList.hpp"

using namespace std;

void checkConst(const GroceryList &cgl)
{
  cout << cgl.getLength() << endl;
  cout << cgl << endl;

  GroceryList temp;
  temp=cgl;

  temp+=cgl;

  GroceryItem *ptr = cgl["Robot"];
  if (ptr!=NULL)
    cout << "found:" << *ptr << endl;
}

int main(int argc, char* argv[])
{
  cout << "If you're seeing this print at run time,"
       << " this test case compiled ..." << endl
       << " ... which is the main pont of this test case." << endl;
  
  ifstream ifile("ShoppingList2.txt");

  GroceryList shopping;
  GroceryItem temp;
  
  ifile >> temp;
 
  while (ifile)
    {
      shopping+=temp;

      ifile>>temp;
    }

  ifile.close();

  checkConst(shopping);

  

  return 0;
}
