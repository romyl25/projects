#include <fstream>
#include <iostream>
#include <string>

#include "GroceryItem.hpp"
#include "GroceryList.hpp"

using namespace std;

int main(int argc, char* argv[])
{
  string fname;
  cout << "Enter name of input file: ";
  cin >> fname;

  ifstream ifile(fname.c_str());

  GroceryList shopping;
  GroceryItem temp;
  
  ifile >> temp;
 
  while (ifile)
    {
      shopping+=temp;

      ifile>>temp;
    }

  ifile.close();

  cout << "Number of items in list: "<< shopping.getLength()<<endl;
  cout << "The resulting shopping list:" << endl;
  cout << shopping;

  return 0;
}
