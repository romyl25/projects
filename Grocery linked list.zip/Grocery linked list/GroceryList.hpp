/********************************************
 * Romyal Swarnkar                          *
 * 11/13/2021                           *
 * Computer Science 2                       *
 * Programming Project 3                    *
 ********************************************/

#include <iostream>
#include <string>

#include "GroceryItem.hpp"
class GroceryList {
 private:
  // points to the first item of the current list.
  GroceryItem *head;

 public:
  /**
   * @brief a default (no argument) constructor that initializes “this”
   * GroceryList to contain no actual GroceryItems.
   */
  GroceryList();

  /**
   * @brief return the current number of GroceryItems in “this” GroceryList.
   *
   * @return int the number of items in the list.
   */
  int getLength() const;

  /**
   * @brief overloaded the = operator where the right hand side is another
   * GroceryList. It changes “this” GroceryList so that it contains an
   * exact duplicate of each GroceryItem in the right hand side GroceryList.
   *
   * @return  the copied GroceryList.
   */
  GroceryList operator=(GroceryList);

  /**
   * @brief overloaded the += operator where the right hand side is a
   * GroceryItem.The GroceryItem on the right hand side is added to
   * “this” GroceryList. If the GroceryItem already exists in “this”
   * GroceryList, then the corresponding quantity in “this” GroceryList
   * is updated to be the sum of the two associated quantities. The right hand
   * side GroceryItem is not modified by this process.
   *
   * @return A copy of the new GroceryList is returned.
   */
  GroceryList operator+=(const GroceryItem &);

  /**
   * @brief overloaded the += operator. The right hand side is another
   * GroceryList. Each GroceryItem in the right hand side is added to
   * “this” GroceryList and a copy of the resulting
   * GroceryList is returned.
   *
   *@return resulting GroceryList after the items are added.
   */
  GroceryList operator+=(const GroceryList &);

  /**
   * @brief overloaded the -= operator. The right hand side is a string. This
   * string represents the name of a GroceryItem. If such an item is found
   * in the GroceryList, then that item will removed from the GroceryList.
   *
   * @return  A copy of the resulting GroceryList is returned.
   */
  GroceryList operator-=(const std::string &);

  /**
   * @brief overloaded the [] operator. When the value between the []’s is a
   * string, it returns a pointer to the corresponding GroceryItem if it
   * is found in “this” GroceryList, and NULL otherwise.
   *
   * @return Pointer to GroceryItem if found or NULL otherwise.
   */
  GroceryItem *operator[](const std::string &) const;

  /**
   * @brief a method called checkOff, which takes a single string
   * parameter representing the name of a GroceryItem to be marked as purchased,
   * unless such a GroceryItem is not found in “this” GroceryList.
   *
   */
  void checkOff(const std::string &);

  /**
   * @brief overloaded the << operator to output to a stream. This outputs
   * each GroceryItem in the associated GroceryList, one per line.
   *
   */
  friend std::ostream &operator<<(std::ostream &os, const GroceryList &li);
};