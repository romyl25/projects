'''
Created on Dec 9, 2018

@author: imrom
'''
import tkinter
from tkinter import ttk
import requests


class MoviesDB:
    
    
    def __init__(self, master):
        self.master = master
        self.createWidgets()
        
        
    #label to display some text       
    def createWidgets(self):
        self.movie_label = ttk.Label(self.master, text='Search for a Movie', background='white', font=('oxygen', 22))
        self.movie_label.grid(row=0, sticky='w', padx=50, pady=25)
        
        #creating an entry box
        self.entry = ttk.Entry(self.master, width=50)
        self.entry.grid(row=1, sticky='w', padx=50, pady=5, ipady=4)

        #creating a button
        self.button = ttk.Button(text='Go', command=self.getMovie)
        self.button.grid(row=2, sticky='w', padx=50, pady=5)

        #creating a frame to display movie information
        self.movie_frame = ttk.Frame(self.master, width=940, height=300, relief='groove')
        
        #so the frame does not shrink to the size of widgets inside it
        self.movie_frame.grid_propagate(False)
        self.movie_frame.grid(row=3, sticky='w', padx=50, pady=5)

    #To get movie data
    def getMovie(self):
        if self.movie_frame.grid_slaves():
            self.clearContents()

        endpoint = "http://www.omdbapi.com/"
        
        #dictionary to include in the url
        payload = {"apikey": "ca9dc15e", "t": self.entry.get()}  # 't' is the search criteria
        #this will get the response from the movie api
        response = requests.get(endpoint, params=payload)
        movie = response.json()  # movie data in json format

        keys = ['Title', 'Year', 'Rated', 'Runtime', 'Genre', 'Director', 'Actors', 'Plot', 'Language', 'Country', 'Awards', 'Poster', 'imdbRating']

        for item in keys:
            text_val = item + " : " + movie[item]
            #creating a label and putting inside a frame
            ttk.Label(self.movie_frame,
                      text=text_val,
                      font=('oxygen', 11),
                      wraplength=940).grid(padx=3, pady=3, sticky='w')
        self.entry.delete(0, 'end')  # remove contents of the entry box
        
        
    #To clear the contents after a search
    def clearContents(self):
        for widget in self.movie_frame.grid_slaves():
            widget.destroy()



if __name__ == '__main__':
    master = tkinter.Tk()
    MoviesDB(master)
    master.title('Movies Database')
    master.geometry('1200x650+125+50')
    master.mainloop()
    

