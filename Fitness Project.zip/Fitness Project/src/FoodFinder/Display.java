package FoodFinder;

public class Display {
    private String diet;
    private String title;
    public Display() { } // default constructor
    public Display(String url, String diet, String title) {
    	this.diet = diet;
    	this.title = title;
    }

    public String getDiet() {
    	return diet;
    }
    
    public void setDiet(String diet) {
    	this.diet = diet;
    }

    public String getTitle() {
    	return title;
    }
    
    public void setTitle(String title) {
    	this.title = title;
    }
}
