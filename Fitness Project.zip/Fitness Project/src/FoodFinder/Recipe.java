package FoodFinder;

import java.io.Serializable;

public class Recipe implements Serializable {
	private static final long serialVersionUID = 1L;
    private String url;
    private String diet;
    private String title;
    private String[] ingredients = new String[25];
    private String[] directions = new String[25];
    
    public Recipe() { } // default constructor
    public Recipe(String url, String diet, String title) {
    	this.url = url;
    	this.diet = diet;
    	this.title = title;
    }
    
    public String getUrl() {
    	return url;
    }
    
    public void setUrl(String url) {
    	this.url = url;
    }

    public String getDiet() {
    	return diet;
    }
    
    public void setDiet(String diet) {
    	this.diet = diet;
    }

    public String getTitle() {
    	return title;
    }
    
    public void setTitle(String title) {
    	this.title = title;
    }

   public String[] getIngredients() {
    	return ingredients;
    }
    
    public void setIngredients(String[] ingredients) {
    	for (int i = 0; i < ingredients.length; i++) {	
    	  this.ingredients[i] = ingredients[i];
    	}
    }

    public String[] getDirections() {
    	return directions;
    }
    
    public void setDirections(String[] directions) {
    	for (int i = 0; i < directions.length; i++) {	
      	  this.directions[i] = directions[i];
    	}
    }
}
