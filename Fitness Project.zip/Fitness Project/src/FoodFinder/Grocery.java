package FoodFinder;

import java.io.Serializable;

public class Grocery implements Serializable {
	private static final long serialVersionUID = 1L;
//    private String items[] = new String[25];
//    private String quantity[] = new String[25];
  private String item;
  private String quantity;
	    
    public Grocery() { } // default constructor
    
    public String getItem() {
    	return item;
    }

    public void setItem(String item) {
    	this.item = item;
    }
    
    public String getQuantity() {
    	return quantity;
    }

    public void setQuantity(String quantity) {
    	this.quantity = quantity;
    }
    
/*	       
    public String[] getItems() {
    	return items;
    }
	    
    public void setItems(String[] items) {
       	for (int i = 0; i < items.length; i++) {	
       	  this.items[i] = items[i];
       	}
    }

    public String[] getQuantity() {
    	return quantity;
    }
	    
    public void setQuantity(String[] quantity) {
       	for (int i = 0; i < quantity.length; i++) {	
       	  this.quantity[i] = quantity[i];
       	}
    }
*/    
}

