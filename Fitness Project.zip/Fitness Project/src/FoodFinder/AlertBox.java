package FoodFinder;

import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.geometry.*;

// reference youTube video thenewboston JavaFx Java GUI Tutorial 5
public class AlertBox {
    public static void display(String title, String message) {
    	Stage window = new Stage();
    	
    	window.initModality(Modality.APPLICATION_MODAL);
    	window.setTitle(title);
    	window.setMinWidth(250);
    	
    	Label label = new Label();
    	label.setText(message);
    	Button closeButton = new Button("Close");
    	closeButton.setOnAction(e -> window.close());
    	
    	VBox layout = new VBox(10);
    	layout.getChildren().addAll(label, closeButton);  // youtube video thenewboston JavaFx Jave GUI Tutorial 5
    	layout.setAlignment(Pos.CENTER);
    	
    	Scene scene = new Scene(layout);
    	window.setScene(scene);
        window.showAndWait();
    }
}
