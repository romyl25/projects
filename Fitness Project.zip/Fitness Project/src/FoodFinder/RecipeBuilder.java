package FoodFinder;


import javafx.application.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.web.*;
import javafx.stage.*;

import java.io.IOException;
import java.util.ArrayList;

import org.jsoup.*;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

// suggested youTube videos, thenewboston JavaFx Java GUI Tutorials and ProgrammingKnowledge JaveFx (not Scene Builder - doesn't work on Java 8)
// use JSoup to parse HTML files, note in Firefox to view webpage HTML when webpage open, press ALT key, select Tools->Web Developer->Pace Source
// load JaveFX from this Eclipse IDE (Help->Install New Software) Go to website: wwww.e(fx)clipse.org/efxclipse/install.html  I picked For the lazy
public class RecipeBuilder extends Application
{
	private Stage window;
	private TableView<Display> table;
	ObservableList<Recipe> recipes = FXCollections.observableArrayList();
	ObservableList<Display> displays = FXCollections.observableArrayList();
	ArrayList<Recipe> info = new ArrayList<>();
	
	public static void main(String[] args)
	{
		launch(args);
	}
	
    @SuppressWarnings("unchecked")
	@Override
    public void start(Stage primaryStage) throws Exception
    {
        final String url_0 = "http://google.com";
        final String url_1 = "https://www.olivetomato.com/10-quick-and-easy-mediterranean-recipes/";
        final String url_2 = "https://palm.southbeachdiet.com/recipes/";
        final String url_3 = "https://www.goodhousekeeping.com/food-recipes/healthy/g807/vegan-recipes/";
        final String url_4 = "https:/www.bbcgoodfood.com/recipes/collection/healthy-vegetarian";
        MakeFiles make = new MakeFiles();
        make.MakeFake();
        make.MakeArchive(); 
//        make.MakeOther();

        window = primaryStage;
        window.setTitle("CPT-200 Menu App - Main Window");
        // main window grid pane        
        GridPane grid = new GridPane();
        javafx.geometry.Insets insets = new javafx.geometry.Insets(10, 10, 10, 10);
        grid.setPadding(insets);
        grid.setVgap(8);
        grid.setHgap(10);

        // declare components
        Label prefLabel = new Label("Preference");
        RadioButton medRadioBtn = new RadioButton("Mediterranean");
        RadioButton southRadioBtn = new RadioButton("South Beach");
        RadioButton veganRadioBtn = new RadioButton("Vegan");
        RadioButton vegetRadioBtn = new RadioButton("Vegetarian");
        Button backButton    = new Button("      <----   Back       ");
        Button addButton     = new Button("  Add Recipe to List ");
        Button deleteButton  = new Button("   Delete From List   ");
        Button recipeButton  = new Button("View Recipe Archive");
        Button shoppingButton = new Button(" View Shopping List ");
        Label urlLabel = new Label("website:");
        urlLabel.setVisible(false);
        WebView webView = new WebView();
        webView.setMaxSize(600, 600);
        WebEngine webEngine = webView.getEngine();
        urlLabel.textProperty().bind(webEngine.locationProperty());
    	// name table columns
    	TableColumn<Display, String> dietColumn = new TableColumn<>("Diet");
    	dietColumn.setMinWidth(100);
    	dietColumn.setCellValueFactory(new PropertyValueFactory<Display, String>("diet"));
    	TableColumn<Display, String> titleColumn = new TableColumn<>("Title");
    	titleColumn.setMinWidth(500);
    	titleColumn.setCellValueFactory(new PropertyValueFactory<Display, String>("title"));
    	
    	table = new TableView<>();
    	table.setItems(displays);
    	table.setMinSize(600, 100);
    	table.getColumns().addAll(dietColumn, titleColumn);
        
        // place components on grid
        GridPane.setConstraints(prefLabel, 0, 3);
        GridPane.setConstraints(urlLabel, 2, 0); // place at column = 2, row = 0
        GridPane.setConstraints(medRadioBtn, 0, 5);
        GridPane.setConstraints(southRadioBtn, 0, 7);
        GridPane.setConstraints(veganRadioBtn, 0, 9);
        GridPane.setConstraints(vegetRadioBtn, 0, 11);
        GridPane.setConstraints(backButton, 0, 13);
        GridPane.setConstraints(addButton, 0, 24);
        GridPane.setConstraints(deleteButton, 0, 38);
        GridPane.setConstraints(recipeButton, 0, 26);
        GridPane.setConstraints(shoppingButton, 0, 28);
        GridPane.setConstraints(webView, 2, 2, 2, 35); // spanning rows and columns
        GridPane.setConstraints(table, 2, 38);
        // set Toggle group for radio buttons
        ToggleGroup prefGroup = new ToggleGroup();
        medRadioBtn.setToggleGroup(prefGroup);
        southRadioBtn.setToggleGroup(prefGroup);
        veganRadioBtn.setToggleGroup(prefGroup);
        vegetRadioBtn.setToggleGroup(prefGroup);
        // define actions for components
        medRadioBtn.setOnAction(e -> webEngine.load(url_1));
        southRadioBtn.setOnAction(e -> webEngine.load(url_2));
        veganRadioBtn.setOnAction(e -> webEngine.load(url_3));
        vegetRadioBtn.setOnAction(e -> webEngine.load(url_4));
        addButton.setOnAction(e -> {
            if (prefGroup.getSelectedToggle() != null)
            {
          	    if (prefGroup.getSelectedToggle() == medRadioBtn)
        	    {
        		    addRecipe("Mediterranean", urlLabel.getText());
        	    }
        	    else if (prefGroup.getSelectedToggle() == southRadioBtn)
        	    {
        	    	addRecipe("South Beach", urlLabel.getText());
        	    }
        	    else if (prefGroup.getSelectedToggle() == veganRadioBtn)
        	    {
        	    	addRecipe("Vegan", urlLabel.getText());
        	    }
        	    else if (prefGroup.getSelectedToggle() == vegetRadioBtn)
        	    {
        	    	addRecipe("Vegetarian", urlLabel.getText());
        	    }
        	    else
        	    {
        	    	addRecipe("Default", urlLabel.getText());
        	    }
            }
        });
        
        backButton.setOnAction(e -> {
        	String oldUrl = urlLabel.getText();
        	int end = oldUrl.lastIndexOf('/');
        	String temp = oldUrl.substring(0, end);
        	end = temp.lastIndexOf('/');
        	String newUrl = temp.substring(0, end);
        	webEngine.load(newUrl);
        });
        
        deleteButton.setOnAction(e -> {
            ObservableList<Display> recipeSelected, allRecipes;
            allRecipes = table.getItems();
            recipeSelected = table.getSelectionModel().getSelectedItems();
            recipeSelected.forEach(allRecipes::remove);
            displays.remove(recipeSelected);
        });
        
        table.setOnMouseClicked((MouseEvent event) -> {
        	if(event.getButton().equals(MouseButton.PRIMARY)) {
                int index = table.getSelectionModel().getSelectedIndex();
                Display displays = table.getItems().get(index);   
                webEngine.load(info.get(index).getUrl());
        	}
        });
        
        webEngine.load(url_0); // initial webpage
        
/***** need to build table see youTube videos, thenewboston JavaFx Java GUI Tutorials 17-20 on TableView  ****************************/
        grid.getChildren().addAll(prefLabel, urlLabel, medRadioBtn, southRadioBtn, veganRadioBtn, vegetRadioBtn,
        		                  backButton, addButton, deleteButton, recipeButton, shoppingButton, table, webView);
        Scene scene = new Scene(grid, 800, 700);
        recipeButton.setOnAction(e -> recipes = Archive.display(info));
        shoppingButton.setOnAction(e -> Shopping.display(recipes));
        
        window.setScene(scene);
        window.show();
        
        window.setOnCloseRequest(e -> {
        	e.consume();
        	closeProgram();
        });
    }
/*    
    // used to load table only type and title
    public ObservableList<Recipe> getRecipe() {
//    	ObservableList<Recipe> recipes = FXCollections.observableArrayList();
    	return recipes;
    }
*/    
    private void addRecipe(String dietType, String url) {
    	try {
			Document doc = Jsoup.connect(url).get();
			String title = doc.title();
			Recipe recipe = new Recipe();
			recipe.setUrl(url);
			recipe.setDiet(dietType);
			recipe.setTitle(title);
			info.add(recipe);
			Display display = new Display();
			display.setDiet(dietType);
			display.setTitle(title);
			displays.add(display);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
   }
   
    private void closeProgram() {
    	Boolean answer = ConfirmBox.display("Confirmation", "Are you sure you want to exit?");
    	if (answer) {
    		window.close();
    	}
    }    
}
