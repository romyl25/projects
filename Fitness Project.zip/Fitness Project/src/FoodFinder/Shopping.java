package FoodFinder;

import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

/*  for TableView edit boxes see YouTube "JavaFX Java GUI Tutorial - 17 - 20 - by thenewboston
 *  need to access Recipe class for observable list and create new classes to store Grocery List and you need to create Others List
 *  need to be able to edit either table and when window closed, combine list into shopping list and save as file
 */
public class Shopping {
    public static void display(ObservableList<Recipe> recipes) { // this is the list of recipes that you need to grab ingredients
    	TableView<Grocery> grocery;
    	TableView<Other> others;
    	TextField quantGrocery, quantOthers, descrGrocery, descrOthers;
    	Stage window = new Stage();
        window.setTitle("CPT-200 Menu App - Shopping Dialog");
    	window.initModality(Modality.APPLICATION_MODAL);
    	window.setMinWidth(600);
        // main window grid pane        
        GridPane grid = new GridPane();
        javafx.geometry.Insets insets = new javafx.geometry.Insets(10, 10, 10, 10);
        grid.setPadding(insets);
        grid.setVgap(8);
        grid.setHgap(10);
        // declare components
        Label groceryLabel = new Label("Grocery List");
        Label othersLabel = new Label("Other Stuff");
    	// create button
    	Button viewButton  = new Button("View List");
    	// name table columns
    	TableColumn<Grocery, String> quantityColumn = new TableColumn<>("Quantity");
    	quantityColumn.setMinWidth(100);
    	quantityColumn.setCellValueFactory(new PropertyValueFactory<Grocery, String>("quantity"));
    	TableColumn<Grocery, String> descriptionColumn = new TableColumn<>("Description");
    	descriptionColumn.setMinWidth(500);
    	descriptionColumn.setCellValueFactory(new PropertyValueFactory<Grocery, String>("item"));    	
    	grocery = new TableView<>();
    	grocery.setItems(getGrocery(grocery));
    	grocery.setMinSize(600, 300);
    	grocery.getColumns().addAll(quantityColumn, descriptionColumn);
    	TableColumn<Other, String> quantColumn = new TableColumn<>("Quantity");
    	quantColumn.setMinWidth(100);
    	quantColumn.setCellValueFactory(new PropertyValueFactory<Other, String>("quantity"));
    	TableColumn<Other, String> descripColumn = new TableColumn<>("Description");
    	descripColumn.setMinWidth(500);
    	descripColumn.setCellValueFactory(new PropertyValueFactory<Other, String>("item"));    	
    	others = new TableView<>();
    	others.setItems(getOthers(others));
    	others.setMinSize(600, 300);
    	others.getColumns().addAll(quantColumn, descripColumn);
        // set up for edit fields
    	quantGrocery = new TextField();
    	quantGrocery.setPromptText("Quantity");
    	quantGrocery.setMaxWidth(100);
    	descrGrocery = new TextField();
    	descrGrocery.setPromptText("Description");
    	descrGrocery.setMinWidth(400);
     	quantOthers = new TextField();
     	quantOthers.setPromptText("Quantity");
     	quantOthers.setMaxWidth(100);
    	descrOthers = new TextField();
    	descrOthers.setPromptText("Description");
    	descrOthers.setMinWidth(400);
    	// table buttons
    	Button addGroBtn  = new Button("Add");
    	Button editGroBtn = new Button("Edit");
    	Button deleteGroBtn = new Button("Delete");
    	Button addOthBtn  = new Button("Add");
    	Button editOthBtn = new Button("Edit");
    	Button deleteOthBtn = new Button("Delete");
//        javafx.geometry.Insets insets = new javafx.geometry.Insets(10, 10, 10, 10);
    	HBox GroBox = new HBox();
//    	GroBox.setPadding(insets);
    	GroBox.setSpacing(10);
    	GroBox.getChildren().addAll(quantGrocery, descrGrocery, addGroBtn, editGroBtn, deleteGroBtn);
    	HBox OthBox = new HBox();
//    	OthBox.setPadding(insets);
    	OthBox.setSpacing(10);
    	OthBox.getChildren().addAll(quantOthers, descrOthers, addOthBtn, editOthBtn, deleteOthBtn);
        // place components on grid
        GridPane.setConstraints(groceryLabel, 0, 1);
        GridPane.setConstraints(othersLabel, 0, 2);
        GridPane.setConstraints(viewButton, 0, 2); // place on left side
        GridPane.setConstraints(grocery, 5, 0);
        GridPane.setConstraints(GroBox, 5, 2); // place on left side
        GridPane.setConstraints(others, 5, 3);
        GridPane.setConstraints(OthBox, 5, 4); // place on left side
        grid.getChildren().addAll(grocery, others, viewButton, GroBox, OthBox);
        viewButton.setOnAction(e -> ShopList.display(buildList(grocery, others)));
        Scene scene = new Scene(grid, 800, 700);
        window.setScene(scene);
        window.show();
   	
        window.setOnCloseRequest(e -> {
        	// To do any clean up before closing window, like writing shopping list to file
        });
        
        addGroBtn.setOnAction(e -> addGroBtnClicked(grocery, quantGrocery, descrGrocery));
        editGroBtn.setOnAction(e -> editGroBtnClicked(grocery, quantGrocery, descrGrocery));
        deleteGroBtn.setOnAction(e -> deleteGroBtnClicked(grocery));
        addOthBtn.setOnAction(e -> addOthBtnClicked(others, quantOthers, descrOthers));
        editOthBtn.setOnAction(e -> editOthBtnClicked(others, quantOthers, descrOthers));
        deleteOthBtn.setOnAction(e -> deleteOthBtnClicked(others));
    }
    
    public static void addGroBtnClicked(TableView<Grocery> grocery, TextField quantGrocery, TextField descrGrocery) {
    	Grocery stuff = new Grocery();
    	stuff.setQuantity(quantGrocery.getText());
    	stuff.setItem(descrGrocery.getText());
    	grocery.getItems().add(stuff);
    	quantGrocery.clear();
    	descrGrocery.clear();
    }
    
    public static void editGroBtnClicked(TableView<Grocery> grocery, TextField quantGrocery, TextField descrGrocery) {
    	ObservableList<Grocery> stuffSelected, allStuff;
    	allStuff = grocery.getItems();
    	stuffSelected = grocery.getSelectionModel().getSelectedItems();
    	stuffSelected.forEach(allStuff::remove);
    	int index = grocery.getSelectionModel().getSelectedIndex();
    	grocery.getItems().get(index);
        Grocery stuff = new Grocery();
    	stuff.setQuantity(quantGrocery.getText());
    	stuff.setItem(descrGrocery.getText());
//    	stuffSelected.set(index, stuff);   	
    	grocery.getItems().add(stuff);
    	quantGrocery.clear();
    	descrGrocery.clear();
   }
    
    public static void deleteGroBtnClicked(TableView<Grocery> grocery) {
    	ObservableList<Grocery> stuffSelected, allStuff;
    	allStuff = grocery.getItems();
    	stuffSelected = grocery.getSelectionModel().getSelectedItems();
    	stuffSelected.forEach(allStuff::remove);
    }
    
    public static void addOthBtnClicked(TableView<Other> others, TextField quantOthers, TextField descrOthers) {
    	Other stuff = new Other();
    	stuff.setQuantity(quantOthers.getText());
    	stuff.setItem(descrOthers.getText());
    	others.getItems().add(stuff);
    	quantOthers.clear();
    	descrOthers.clear();    	
    }
       
    public static void editOthBtnClicked(TableView<Other> others, TextField quantOthers, TextField descrOthers) {
    	ObservableList<Other> stuffSelected, allStuff;
    	allStuff = others.getItems();
    	stuffSelected = others.getSelectionModel().getSelectedItems();
    	stuffSelected.forEach(allStuff::remove);
    	int index = others.getSelectionModel().getSelectedIndex();
    	others.getItems().get(index);
        Other stuff = new Other();
    	stuff.setQuantity(quantOthers.getText());
    	stuff.setItem(descrOthers.getText());
    	others.getItems().add(stuff);
    	quantOthers.clear();
    	descrOthers.clear();
    	
    }
    
    public static void deleteOthBtnClicked(TableView<Other> others) {
    	ObservableList<Other> stuffSelected, allStuff;
    	allStuff = others.getItems();
    	stuffSelected = others.getSelectionModel().getSelectedItems();
    	stuffSelected.forEach(allStuff::remove);    	
    }
/* This method is for you to see the recipe list passed in from RecipeBuilder (main window) */    
    // used to load table only type and title
    public static ObservableList<Grocery> getGrocery(TableView<Grocery> grocery) {
        ArrayList<Grocery> list = new ArrayList<>();
    	Grocery stuff;
        String quantity[] = new String[25];
        String item[] = new String[25];
    	// To do: you will need to read recipe from file and store into archive list. archive list is of type Recipe Class
        quantity[0] = "6 ";
        quantity[1] = "1� pounds ";
        quantity[2] = "1 lb. ";
        quantity[3] = "1 large head ";
        quantity[4] = "8 ";
        quantity[5] = "� pound ";
        quantity[6] = "12 ounces ";
        quantity[7] = "3 cup ";
        quantity[8] = "5 tablespoons ";
        quantity[9] = "5 tbsp. ";
        quantity[10] = "2 tablespoon ";
        quantity[11] = "4 teaspoon ";
        quantity[12] = "1 tablespoon ";
        quantity[13] = "6 cups ";
        quantity[14] = "6 ";
        quantity[15] = "5 ";
        quantity[16] = "1 cup ";
        quantity[17] = "4 cups ";
        quantity[18] = "2 sweet ";
        quantity[19] = "250g ";
        quantity[20] = "600ml ";
        quantity[21] = "80g bag ";
        quantity[22] = "1l ";
        quantity[23]= "2 x 400g cans ";
        quantity[24] = " ";
        item[0] = "red bell peppers sliced";
        item[1] = "pasta";
        item[2] = "chicken breast, boneless and skinless";
        item[3] = "cauliflower";
        item[4] = "tomatoes";
        item[5] = "sliced sausage";
        item[6] = "feta";
        item[7] = "Greek yogurt";
        item[8] = "cream cheese";
        item[9] = "canola oil";
        item[10] = "parsley";
        item[11] = "dry oregano";
        item[12] = "mint";
        item[13] = "olive oil";
        item[14] = "onion";
        item[15] = "peppers";
        item[16] = "chopped olives";
        item[17] = "medium grain rice";
        item[18] = "sweet potatoes (about 400g/14oz), cut into even chunks";
        item[19] = "red split lentils";
        item[20] = "vegetable stock";
        item[21] = "bag of spinach";
        item[22] = "vegetable stock";
        item[23]=  "chickpeas, drained";
        item[24] = "Pepper/Salt";
        for (int i = 0; i < 25; i++) {
        	stuff = new Grocery();
        	stuff.setItem(item[i]);
        	stuff.setQuantity(quantity[i]);
        	list.add(stuff);
        }
    	ObservableList<Grocery> obsList = FXCollections.observableArrayList(list);    	
    	return obsList;
    }
    
    // used to load table only type and title
    public static ObservableList<Other> getOthers(TableView<Other> others) {
        ArrayList<Other> list = new ArrayList<>();
    	Other stuff;
        String quantity[] = new String[13];
        String item[] = new String[13];
        Other other = new Other();
        quantity[0] = "4 rolls ";
        quantity[1] = "2 boxes ";
        quantity[2] = "1 loaf ";
        quantity[3] = "1 box ";
        quantity[4] = "2 gal. ";
        quantity[5] = "1 bottle ";
        quantity[6] = "4 ";
        quantity[7] = "bunch ";
        quantity[8] = "1 bottle ";
        quantity[9] = "1 jar ";
        quantity[10] = "2 bottles ";
        quantity[11] = "1 box ";
        quantity[12] = "1 bag ";
        item[0] = "paper towels";
        item[1] = "lightbulbs";
        item[2] = "frech bread";
        item[3] = "tea bags";
        item[4] = "milk";
        item[5] = "Windex";
        item[6] = "Sponges";
        item[7] = "bananas";
        item[8] = "honey";
        item[9] = "peanut butter";
        item[10] = "red wine";
        item[11] = "dryer sheets";
        item[12] = "dog food";
        for (int i = 0; i < 13; i++) {
        	stuff = new Other();
        	stuff.setItem(item[i]);
        	stuff.setQuantity(quantity[i]);
        	list.add(stuff);
        }
    	ObservableList<Other> obsList = FXCollections.observableArrayList(list);
    	return obsList;
    }

    public static String[] buildList(TableView<Grocery> grocery, TableView<Other> others) {
    	ObservableList<Grocery> food = FXCollections.observableArrayList();
    	ObservableList<Other> stuff = FXCollections.observableArrayList();
        ArrayList<String> strArray = new ArrayList<>();
        String both;
    	food = (ObservableList<Grocery>) grocery.getItems();
    	strArray.add("FOOD:");
        for (int i = 0; i < food.size(); i++) {
        	both = food.get(i).getQuantity() + food.get(i).getItem();
        	strArray.add(both);
        }
        stuff = (ObservableList<Other>) others.getItems();
    	strArray.add("\nSTUFF:");
        for (int i = 0; i < stuff.size(); i++) {
        	both = stuff.get(i).getQuantity() + stuff.get(i).getItem();
        	strArray.add(both);        	
        }
    	String[] list = new String[strArray.size()];
    	for (int i = 0; i < strArray.size(); i++) {
    		list[i] = strArray.get(i);
    	}
    	return list;
    }
}
