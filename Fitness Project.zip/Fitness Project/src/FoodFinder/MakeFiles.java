package FoodFinder;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

//import loadRecipe.Recipe;

public class MakeFiles {
	public static void MakeFake() throws ClassNotFoundException {
		ArrayList<Recipe> recipes = new ArrayList<>();
		ArrayList<Recipe> read = new ArrayList<>();
        try {
        	String fileName = "Fake.bin";
            Recipe recipe;
            FileOutputStream f = new FileOutputStream(new File(fileName));
        	ObjectOutputStream o = new ObjectOutputStream(f);
            String ingredients[] = new String[20];
            String directions[] = new String[20];
            
/////// mediterranean - Greek Style Macaroni and Feta Cheese
            recipe = new Recipe();
            ingredients[0] = "INGREDIENTS:";
            ingredients[1] = "� pound pasta";
            ingredients[2] = "3 ounces feta";
            ingredients[3] = "� cup Greek yogurt";
            ingredients[4] = "2-3 tablespoons cream cheese";
            ingredients[5] = "1 tablespoon parsley";
            ingredients[6] = "1 teaspoon dry oregano";
            ingredients[7] = "1 tablespoon mint";
            ingredients[8] = "3 tablespoon olive oil";
            ingredients[9] = "1 onion chopped";
            ingredients[10] = "1 pepper chopped";
            ingredients[11] = "� cup chopped olives";
            ingredients[12] = "Pepper/Salt to taste";
            recipe.setIngredients(ingredients);
            directions[0] = "DIRECTIONS:";
            directions[1] = "1. Preheat oven at 350 Fahrenheit (180 C)";
            directions[2] = "2. Boil the pasta according to the directions";
            directions[3] = "3. In a pan heat about 1 � tablespoon olive oil and saute the onion and pepper until soft.";
            directions[4] = "4. Add the herbs and olives and saute for 1-2 minutes. Set aside.";
            directions[5] = "5. In a bowl mash the feta with yogurt and cream cheese until creamy.  Add some pepper.";
            directions[6] = "6. Once the pasta is boiled, drain and put back in the pot and add the cooked vegetables and the rest of the olive oil.";
            directions[7] = "7. Add the cheese sauce and mix well. You can sprinkle a small amount of dry cheese such as parmesan on top.";
            directions[8] = "8. Pour into a cassrole and bake in the oven for about 20 minutes.";
            recipe.setDirections(directions);
            recipes.add(recipe);

/// mediterranean Sausage and peppers - Spetzofai
            recipe = new Recipe();
            ingredients[0] = "INGREDIENTS:";
            ingredients[1] = "2 red bell peppers sliced";
            ingredients[2] = "2 green bell peppers sliced";
            ingredients[3] = "3 ounces sliced sausage";
            ingredients[4] = "1/3 cup olive oil";
            ingredients[5] = "2 garlic cloved sliced thinly";
            ingredients[6] = "1 A pinch of sugar";                      /// units
            ingredients[7] = "1/4 teaspoon salt";
            ingredients[8] = "12 ounces chopped tomato";
            ingredients[9] = "freshly ground pepper";
            ingredients[10] = "2 teaspoons Dry oregano";
            recipe.setIngredients(ingredients);
            directions[0] = "DIRECTIONS:";
            directions[1] = "1. In a large pan heat the olive oil.";
            directions[2] = "2. Saute the peppers and sausage for about 5 minutes.";
            directions[3] = "3. Add the sugar, salt and garlic. Saute for a few seconds, and then add the tomato. Stir well.";
            directions[4] = "4. Lower the heat and simmer for about 20 minutes.";
            directions[5] = "5. Add very little hot water if needed while simmering.";
            directions[6] = "6. Remove from pan. Sprinkle some oregano and add some pepper.";
            directions[7] = "7. Serve warm of pasta or rice or with bread crumbled feta.";
            recipe.setDirections(directions);            
            recipes.add(recipe);

/// South Beach Diet - Jalapeno Popper Chicken
            recipe = new Recipe();
            ingredients[0] = "INGREDIENTS:";
            ingredients[1] = "1 lb. chicken breast, boneless and skinless";
            ingredients[2] = "8 oz. cream cheese, softened";
            ingredients[3] = "3 jalapenos, seeded and diced";
            ingredients[4] = "3 slices bacon, cooked and crumbled";
            ingredients[5] = "� cup cheddar cheese, shredded";
            ingredients[6] = "Garlic powder, to taste";
            ingredients[7] = "Salt and pepper, to taste";
            recipe.setIngredients(ingredients);
            directions[0] = "DIRECTIONS:";
            directions[1] = "1. Preheat oven to 375�F.";
            directions[2] = "2. Cook bacon until it's crispy. Chop or crumble when it has cooled.";
            directions[3] = "3. Filet the chicken breasts in half so they are thin. Lay the chicken in a 9X9 baking dish.";
            directions[4] = "4. Season the chicken with garlic powder, salt and pepper to taste.";
            directions[5] = "5. Using a spoon, spread the softened cream cheese over the top of the chicken evenly.";
            directions[6] = "6. Slice the jalapenos in half and remove the seeds and veins to reduce heat. Dice the finely."
            		     +  " Wear plastic gloves to protect your skin from the jalapenos if desired.";
            directions[7] = "7. Evenly top the chicken with diced jalapeno and bacon bits.";
            directions[8] = "8. Top evenly with the chredded cheddar cheese.";
            directions[9] = "9. Bake uncovered in a preheated oven for 25 t0 30 minutes or until chicken is cooked completely.";
            directions[10] = "10. Allow the chicken to cool for about 5 minutes before serving.";
            recipe.setDirections(directions);            
            recipes.add(recipe);

/// Vegan - Roasted Cauliflower Steak - Good Housekeeping
            recipe = new Recipe();
            ingredients[0] = "INGREDIENTS:";
            ingredients[1] = "1 large head cauliflower";
            ingredients[2] = "1 tbs. ground cumin";
            ingredients[3] = "5 tbsp. canola oil";
            ingredients[4] = "1/4 c. loosely packed cinantro, finely chopped";
            ingredients[5] = "1/4 c. loosely packed parsely leaves, finely chopped";
            ingredients[6] = "3 tbsp. red wine vinegar";
            ingredients[7] = "1 small clove garlic, crushed with press";
            ingredients[8] = "1 jalapeno chile, seeded and finely chopped";
            recipe.setIngredients(ingredients);
            directions[0] = "DIRECTIONS:";
            directions[1] = "1. Trim leaves and any excess stem from cauliflower. Stand cauliflower on stem end and slice off about � inch."
            		      + " Cut 2 slices from center of cauliflower (each about 1 inch thick); reserve rounded wedges for another use.";
            directions[2] = "2. Combine cumin and 1 tbsp. canola oil. Brush all over cauliflower slices.";
            directions[3] = "3. Sprinkle with � tsp salt.";
            directions[4] = "4. In 12 inch oven-safe skillet, heat 2 tbsp. oil on medium-high heat until hot.";
            directions[5] = "5. Add cauliflower; cook 3 minutes. Turn slices over.";
            directions[6] = "6. Place skillet in 425�F oven; roast 15 to 20 minutes or until is tender when pierced with tip of paring knife.";
            directions[7] = "7. Meanwhile, stir together cilantro, parsley, vinegar, garlic, jalapeno, remaining 2 tbsp. oil, and 0.125 tsp. salt.";
            directions[8] = "8. Spoon herb sauce onto finished steaks.";
            recipe.setDirections(directions);            
            recipes.add(recipe);

/// Vegetarian - Spinach, sweet potato & lentil dhal - bbc good food vegetarian
            recipe = new Recipe();
            ingredients[0] = "INGREDIENTS:";
            ingredients[1] = "1 tbsp sesame oil";
            ingredients[2] = "1 red onion, finely chopped";
            ingredients[3] = "1 garlic clove, crushed";
            ingredients[4] = "thumb-sized piece ginger, peeled and finely chopped";
            ingredients[5] = "1 red chilli, finely chopped";
            ingredients[6] = "1 � tsp grouind turmeric";
            ingredients[7] = "1 � tsp ground cumin";
            ingredients[8] = "2 sweet potatoes (about 400g/14oz), cut into even chunks";
            ingredients[9] = "250g red split lentils";
            ingredients[10] = "600ml vegetable stock";
            ingredients[11] = "80g bag of spinach";
            ingredients[12] = "4 spring onions, sliced on the diagonal, to serve";
            ingredients[13] = "� small pack of Thai basil, leaves torn, to serve";
            recipe.setIngredients(ingredients);
            directions[0] = "DIRECTIONS:";
            directions[1] = "1. Heat 1 tbsp sesame oil in a wide-based pan with a tight-fitting lid.";
            directions[2] = "2. Add 1 finely chopped red onion and cook over a low heat for 10 min. stirring occasionally, until softened.";
            directions[3] = "3. Add 1 crushed garlic clove, a finely chopped thumb-sized pieces of ginger and 1 finely chopped red chilli, cook for 1 min,"
            		      + " then add 1.5 tsp ground turmeric and 1.5 tsp ground cumin and cook for 1 min more.";
            directions[4] = "4. Turn up the heat to medium, add 2 sweet potatoes, cut into even chunks, and stir everything together so the potato is coated in the spice mixture";
            directions[5] = "5. Tip in 250g red split lentils, 600ml vegetable stock and some seasoning";
            directions[6] = "6. Bring the liquid to the boil, then reduce the heat, cover and cook for 20 mins until the lentils are tender and the potato is just holding its shape.";
            directions[7] = "7. Taste and adjust the seasoning, the gently stir in the 80g spinich. Once wilted,"
            		      + " top with the 4 diagonally sliced spring onions and 0.5 small pack torn basil leaves to serve.";
            directions[8] = "8. Alternatively, allow to cool completely, then divide between airtight containers and stoe in the fridge for a health lunchbox.";
            recipe.setDirections(directions);            
            recipes.add(recipe);
            o.writeObject(recipes);
            o.close();
            f.close();
        } catch (FileNotFoundException e) {
        	System.out.println("Error: File not Found.");
        } catch (IOException e) {
        	System.out.println("Error in initalizing stream");
        }
	}
	
	public static void MakeArchive() throws ClassNotFoundException {
		ArrayList<Recipe> recipes = new ArrayList<>();
		ArrayList<Recipe> list = new ArrayList<>();
        try {
        	String fileName = "Archive.bin";
            Recipe recipe;
            FileOutputStream f = new FileOutputStream(new File(fileName));
        	ObjectOutputStream o = new ObjectOutputStream(f);
            String ingredients[] = new String[20];
            String directions[] = new String[20];
            String[] stuff;
            String[] todo;
            
/// Vegetarian - Roasted red pepper & tomato soup
            recipe = new Recipe();
            recipe.setDiet("Vegetarian");
            recipe.setTitle("Roasted red pepper & tomato soup with ricotta");
            recipe.setUrl("https://www.bbcgoodfood.com/recipes/roasted-red-pepper-tomato-soup-ricotta");
            ingredients[0] = "INGREDIENTS:";
            ingredients[1] = "400g tomatoes, halved";
            ingredients[2] = "1 red onion, quartered";
            ingredients[3] = "2 Romano peppers, roughly chopped";
            ingredients[4] = "2 tbsp good quality olive oil";
            ingredients[5] = "2 garlic cloves, bashed in their skins";
            ingredients[6] = "few thyme sprigs";
            ingredients[7] = "1 tbsp red wine vinegar";
            ingredients[8] = "2 tbsp ricotta";
            ingredients[9] = "few basil leaves";
            ingredients[10] = "1 tbsp mixed seeds, toasted";
            ingredients[11] = "bread, to serve";
            recipe.setIngredients(ingredients);
            directions[0] = "DIRECTIONS:";
            directions[1] = "1. Heat oven to 200C/180C fan/gas 6. Put the tomatoes, onion and peppers in a roasting tin, toss with the oil and season."
            		      + " Nestle in the garlic and thyme sprigs, then roast for 25-30 mins until all the veg has softened and slightly caramelised."
            		      + " Squeeze the garlic cloves out of their skins into the tin, strip the leaves off the thyme and discard the stalks and garlic skins."
            		      + " Mix the vinegar into the tin then blend everything in a bullet blender or using a stick blender, adding enough water to loosen"
            		      + " to your preferred consistency (we used around 150ml).";
            directions[2] = "2. Reheat the soup if necessary, taste for seasoning, then spoon into two bowls and top each with a spoonful of ricotta,"
            		      + " a few basil leaves, the seeds and a drizzle of oil. Serve with bread for dunking.";
            recipe.setDirections(directions);
            recipes.add(recipe);

/// Vegetarian -  Moroccan chickpea, squash & cavolo nero stew
            recipe = new Recipe();
            recipe.setDiet("Vegetarian");
            recipe.setTitle("Moroccan chickpea, squash & cavolo nero stew");
            recipe.setUrl("https://www.bbcgoodfood.com/recipes/moroccan-chickpea-squash-kale-stew");
            ingredients[0] = "INGREDIENTS:";
            ingredients[1] = "4 tomatoes, halved";
            ingredients[2] = "5 tbsp olive oil";
            ingredients[3] = "250g butternut squash, peeled and chopped into large chunks";
            ingredients[4] = "1 tbsp thyme leaves";
            ingredients[5] = "1 garlic clove, crushed";
            ingredients[6] = "1 onion, sliced";
            ingredients[7] = "2 x 400g cans chickpeas, drained";
            ingredients[8] = "1 bay leaf";
            ingredients[9] = "1 tbsp ground cumin";
            ingredients[10] = "1 tsp ground cinnamon";
            ingredients[11] = "� tsp turmeric";
            ingredients[12] = "1 tbsp harissa";
            ingredients[13] = "1l vegetable stock";
            ingredients[14] = "100g feta, crumbled";
            ingredients[15] = "1 lemon, zested, then cut into wedges";
            ingredients[16] = "2 tsp fennel seeds";
            ingredients[17] = "1 tsp ground coriander";
            ingredients[18] = "200g cavolo nero, shredded";
            ingredients[19] = "handful fresh coriander leaves, to serve";
            recipe.setIngredients(ingredients);
            directions[0] = "DIRECTIONS:";
            directions[1] = "1. Heat oven to 200C/180C fan/gas 6. Put the tomatoes on a baking sheet lined with baking parchment,"
            		      + " drizzle over 2 tbsp olive oil, season and roast in the oven for 20 mins or until soft. Set aside.";
            directions[2] = "2. Meanwhile, pour 2 tbsp oil into a large saucepan and add the squash, thyme, garlic and onion."
            		      + " Season generously and cook on a low heat for 15 mins or until the vegetables begin to soften (but not brown).";
            directions[3] = "3. Add the tomatoes, chickpeas, bay, ground spices and harissa. Season to taste and pour in the stock."
            		      + " Bring to the boil, then reduce the heat and simmer for 30-35 mins until the liquid has reduced.";
            directions[4] = "4. Put the feta in a small bowl and add the remaining olive oil and the lemon zest. Mix well and set aside.";
            directions[5] = "5. Toast the fennel seeds in a frying pan for 1 min, then lightly crush with a pestle and mortar,"
            		      + " or in a bowl with the back of a rolling pin.";
            directions[6] = "6. Add the ground coriander and cavolo nero to the stew and cook for 2 mins. Put the stew in a bowl and top with a scoop"
            		      + " of feta, a sprinkling of coriander leaves and fennel seeds, and some seasoning. Serve with lemon wedges on the side.";
            recipe.setDirections(directions);            
            recipes.add(recipe);

/// vegan -  Grilled Asparagus and Shiitake Tacos - goodhousekeeping
            recipe = new Recipe();
            recipe.setDiet("vegan");
            recipe.setTitle("Grilled Asparagus and Shiitake Tacos");
            recipe.setUrl("https://www.goodhousekeeping.com/food-recipes/a38332/grilled-asparagus-and-shiitake-tacos-recipe/");
            ingredients[0] = "INGREDIENTS:";
            ingredients[1] = "3 tbsp. canola oil";
            ingredients[2] = "1 tsp. ground chipotle chile";
            ingredients[3] = "1/2 tsp. Kosher salt";
            ingredients[4] = "8 oz. shiitake mushrooms, stems discarded";
            ingredients[5] = "8 corn tortillas, warmed";
            ingredients[6] = "1 c. homemade or prepared guacamole";
            ingredients[7] = "Lime wedges";
            ingredients[8] = "cilantro sprigs";
            ingredients[9] = "Hot sauce, for serving";
            recipe.setIngredients(ingredients);
            directions[0] = "DIRECTIONS:";
            directions[1] = "1. Heat grill on medium. In a large baking dish, combine oil, garlic, chipotle, and salt."
            		      + " Add asparagus, shiitakes, and green onions; toss to coat. Grill asparagus until tender and"
            		      + " lightly charred, turning occasionally; 5 to 6 minutes. Grill shiitakes and green onions until"
            		      + " lightly charred, turning occasionally; 4 to 5 minutes. Transfer vegetables to cutting board.";
            directions[2] = "2. Cut asparagus and green onions into 2 lengths and slice shiitakes."
            		      + " Serve with corn tortillas, guacamole, lime wedges, cilantro, and hot sauce.";
            recipe.setDirections(directions);            
            recipes.add(recipe);

/// Vegan - Easy Roasted Veggies and Tempeh Bowl Recipe - Good Housekeeping
            recipe = new Recipe();
            recipe.setDiet("Vegan");
            recipe.setTitle("Easy Roasted Veggies and Tempeh Bowl Recipe");
            recipe.setUrl("https://www.goodhousekeeping.com/food-recipes/healthy/a47216/easy-roasted-veggies-and-tempeh-bowl-recipe/");
            ingredients[0] = "INGREDIENTS:";
            ingredients[1] = "1 c. baby spinach";
            ingredients[2] = "1/2 c. shredded red cabbage";
            ingredients[3] = "1/2 c. quinoa (recipe link in directions)";
            ingredients[4] = "1 c. assorted roasted veggies";
            ingredients[5] = "1 piece roasted tempeh (recipe link in directions)";
            ingredients[6] = "2 tbsp. Chopped cilantro";
            ingredients[7] = "1/4 tsp. toasted sesame oil";
            ingredients[8] = "Sliced radishes";
            ingredients[9] = "lime wedge";
            recipe.setIngredients(ingredients);
            directions[0] = "DIRECTIONS:";
            directions[1] = "1. Fill a bowl with baby spinach, shredded red cabbage, cooked quinoa, and assorted"
            		      + " roasted veggies (we used � cup each tomatoes and broccoli)..";
            directions[2] = "2. Top with roasted tempeh and chopped cilantro; drizzle with toasted sesame oil.";
            directions[3] = "3. Heat in microwave.";
            directions[4] = "4. Garnish with sliced radishes and a lime wedge.";
            recipe.setDirections(directions);            
            recipes.add(recipe);

/// South Beach Diet - Spinach, sweet potato & lentil dhal - bbc good food vegetarian
            recipe = new Recipe();
            recipe.setDiet("South Beach");
            recipe.setTitle("Dessert Chocolate Berry Cups");
            recipe.setUrl("https://palm.southbeachdiet.com/recipes/diet-dessert-chocolate-berry-cups/");
            ingredients[0] = "INGREDIENTS:";
            ingredients[1] = "1 cup mixed berries (blueberries, raspberries, and/or sliced strawberries)";
            ingredients[2] = "1 Tbsp. granular sugar substitute";
            ingredients[3] = "2 (13- by 18-inch) sheets frozen whole-wheat phyllo dough, thawed";
            ingredients[4] = "1 1/2 Tbsp. trans-fat-free margarine, melted";
            ingredients[5] = "1 oz. bittersweet chocolate, chopped";
            ingredients[6] = "1/4 cup ricotta";
            recipe.setIngredients(ingredients);
            directions[0] = "DIRECTIONS:";
            directions[1] = "1. Heat oven to 350�F.";
            directions[2] = "2. Combine berries with sugar substitute. Spread 1 phyllo sheet out on a clean work surface."
            		      + " Lightly brush with margarine. Lay second sheet on top of first; brush with margarine."
            		      + " Fold sheets in half widthwise. Brush top side with more margarine.";
            directions[3] = "3. Cut dough in half lengthwise, then again widthwise to create 4 equal pieces. Carefully fit"
            		      + " each piece into a nonstick muffin pan to create a cup. Bake the cups until golden brown,"
            		      + " about 15 minutes. Set aside to cool.";
            directions[4] = "4. When you are ready to assemble cups, place chocolate in a resealable plastic bag. Heat,"
            		      + " unsealed, in the microwave at 30-second intervals until melted, about 2 minutes."
            		      + " Fill each phyllo cup with 1 tablespoon ricotta and 1/4 cup berries. Cut a tiny corner off"
            		      + " one bottom corner of the plastic bag with scissors; press chocolate toward the corner and"
            		      + " drizzle over berries.";
            recipe.setDirections(directions);            
            recipes.add(recipe);

/////// mediterranean - Greek Spinach and Rice � Spanakokorizo
            recipe = new Recipe();
            recipe.setDiet("Mediterranean");
            recipe.setTitle("Greek Spinach and Rice � Spanakokorizo");
            recipe.setUrl("https://www.olivetomato.com/greek-spinach-and-rice-spanakorizo/");
            ingredients[0] = "INGREDIENTS:";
            ingredients[1] = "1 pound fresh spinach rinsed";
            ingredients[2] = "Juice of half lemon";
            ingredients[3] = "1 onion chopped or 2-3 spring onions chopped";
            ingredients[4] = "2 � tablespoons olive oil plus more for drizzling";
            ingredients[5] = "I teaspoon dry mint";                                  // mistake on website I instead of 1
            ingredients[6] = "1-2 tablespoons chopped dill";
            ingredients[7] = "2/3 cups water";
            ingredients[8] = "1/3 cup medium grain rice";
            ingredients[9] = "Salt/Pepper";
            ingredients[10] = "1 tablespoon tomato paste optional";
            recipe.setIngredients(ingredients);
            directions[0] = "DIRECTIONS:";
            directions[1] = "1. In a large pot wilt the spinach with the lemon juice and 1 teaspoon olive oil."
            		      + " Set aside to drain.";
            directions[2] = "2. In another pot saut� the onion with the rest of the olive oil until soft.";
            directions[3] = "3. Add the spinach, dry mint, dill and 2/3 cup warm water and bring to a boil.";
            directions[4] = "4. Add the rice, salt (as needed) and pepper and simmer for about 20 minutes until"
            		      + " rice is soft. Add additional warm water as needed.";
            directions[5] = "5. Serve warm or at room temperature with a squeeze of lemon juice and a bit of olive"
            		      + " oil and feta.";
            recipe.setDirections(directions);
            recipes.add(recipe);

/// mediterranean Sausage and peppers - Spetzofai
            recipe.setDiet("Mediterranean");
            recipe.setTitle("Feta and Greek Yogurt Pita Appetizer");
            recipe.setUrl("https://www.olivetomato.com/feta-and-greek-yogurt-pita-appetizer/");
            ingredients[0] = "INGREDIENTS:";
            ingredients[1] = "2 round medium pita bread 5-6 inch diameter";
            ingredients[2] = "2 tablespoons crumbled feta about 2 ounces";
            ingredients[3] = "4 tablespoons low fat Greek yogurt";
            ingredients[4] = "2-3 tablespoons chopped mint";
            ingredients[5] = "Fresh ground pepper";
            ingredients[6] = "1 teaspoon olive oil";
            recipe.setIngredients(ingredients);
            directions[0] = "DIRECTIONS:";
            directions[1] = "1. Preheat oven at 400 degrees Fahrenheit (200 Celsius).";
            directions[2] = "2. In a medium bowl, mash the feta with yogurt until creamy. Add the mint and olive oil and blend well.";
            directions[3] = "3. Spread the yogurt-feta mix on each pita.";
            directions[4] = "4. Bake in the oven for about 10 minutes, until tips of pita starts to brown.";
            directions[5] = "5. Take out and cut each pita with a pizza cutter in 6 triangles or 8 and serve.";
            recipe.setDirections(directions);            
            recipes.add(recipe);
            o.writeObject(recipes);
            o.close();
            f.close();
            FileInputStream fi = new FileInputStream(new File(fileName));
            ObjectInputStream oi = new ObjectInputStream(fi);
            list = (ArrayList) oi.readObject();
            for (Recipe object : list) {
          	  stuff = object.getIngredients();
              for (int i = 0; i < stuff.length; i++) {
              	if (stuff[i] != null) { 
//            		System.out.println(stuff[i]);
            	}
              }
           	  todo = object.getDirections();
              for (int i = 0; i < todo.length; i++) {
            	if (todo[i] != null) { 
//           		System.out.println(todo[i]);
            	}
              }            	
            }
        } catch (FileNotFoundException e) {
        	System.out.println("Error: File not Found.");
        } catch (IOException e) {
        	System.out.println("Error in initalizing stream");
        }
	}
/*	
	public static void MakeOther() throws ClassNotFoundException {
        try {
        	String fileName = "Other.bin";
            FileOutputStream f = new FileOutputStream(new File(fileName));
        	ObjectOutputStream o = new ObjectOutputStream(f);
            String itemGrocery[] = new String[25];
            
            Grocery grocery = new Grocery();
            itemGrocery[0] = "6 red bell peppers sliced";
            itemGrocery[1] = "1� pounds pasta";
            itemGrocery[2] = "1 lb. chicken breast, boneless and skinless";
            itemGrocery[3] = "1 large head cauliflower";
            itemGrocery[4] = "8 tomatoes";
            itemGrocery[5] = "� pound sliced sausage";
            itemGrocery[6] = "12 ounces feta";
            itemGrocery[7] = "3 cup Greek yogurt";
            itemGrocery[8] = "5 tablespoons cream cheese";
            itemGrocery[9] = "5 tbsp. canola oil";
            itemGrocery[10] = "2 tablespoon parsley";
            itemGrocery[11] = "4 teaspoon dry oregano";
            itemGrocery[12] = "1 tablespoon mint";
            itemGrocery[13] = "6 cups olive oil";
            itemGrocery[14] = "6 onion";
            itemGrocery[15] = "5 peppers";
            itemGrocery[16] = "1 cup chopped olives";
            itemGrocery[17] = "4 cups medium grain rice";
            itemGrocery[18] = "2 sweet potatoes (about 400g/14oz), cut into even chunks";
            itemGrocery[19] = "250g red split lentils";
            itemGrocery[20] = "600ml vegetable stock";
            itemGrocery[21] = "80g bag of spinach";
            itemGrocery[22] = "1l vegetable stock";
            itemGrocery[23]= "2 x 400g cans chickpeas, drained";
            itemGrocery[24] = "Pepper/Salt";
            grocery.setItems(itemGrocery);
            o.writeObject(grocery);
            o.close();
            f.close();
        } catch (FileNotFoundException e) {
        	System.out.println("Error: File not Found.");
        } catch (IOException e) {
        	System.out.println("Error in initalizing stream");
        }
        try {
        	String fileName = "Other.bin";
            FileOutputStream f = new FileOutputStream(new File(fileName));
        	ObjectOutputStream o = new ObjectOutputStream(f);
            String item[] = new String[13];
            String quantity[] = new String [13];
            Other other = new Other();
            quantity[0] = "4 rolls";
            quantity[1] = "2 boxes";
            quantity[2] = "1 loaf";
            quantity[3] = "1 box";
            quantity[4] = "2 gal.";
            quantity[5] = "1 bottle";
            quantity[6] = "4";
            quantity[7] = "bunch";
            quantity[8] = "1 bottle";
            quantity[9] = "1 jar";
            quantity[10] = "2 bottles";
            quantity[11] = "1 box";
            quantity[12] = "1 bag";
            item[0] = "paper towels";
            item[1] = "lightbulbs";
            item[2] = "frech bread";
            item[3] = "tea bags";
            item[4] = "milk";
            item[5] = "Windex";
            item[6] = "Sponges";
            item[7] = "bananas";
            item[8] = "honey";
            item[9] = "peanut butter";
            item[10] = "red wine";
            item[11] = "dryer sheets";
            item[12] = "dog food";
            other.setQuantity(quantity);
            other.setItems(item);
            o.writeObject(other);
            o.close();
            f.close();
        } catch (FileNotFoundException e) {
        	System.out.println("Error: File not Found.");
        } catch (IOException e) {
        	System.out.println("Error in initalizing stream");
        }
	}
*/
}
