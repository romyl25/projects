package FoodFinder;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import javafx.stage.Stage;


/*  for ListView see YouTube "JavaFX Java GUI Tutorial - 15 - ListView by thenewboston 
*   also see JavaFX 8 Tutorial - JavaFX Collections & ListView - #18 by Life FX
**  also see JavaFX - ListView, ObservableList - by Ken
*
*   Use JSoup to parse URL string with methods
*   	Document doc = Jsoup.connect(url).get();
*		String title = doc.title();
*		Element body = doc.body(); or Node body = doc.body();  // use these to get body and parse for description, ingredients, preparations
**/

public class Archive {
    public static ObservableList<Recipe> display(ArrayList<Recipe> info) { // throws ClassNotFoundException, IOException 
    	ObservableList<Recipe> recipes = FXCollections.observableArrayList();
    	TableView<Recipe> table;
    	TableView<Recipe> archive;
    	ListView<String> list;
    	Stage window = new Stage();
        window.setTitle("CPT-200 Menu App - Archive Dialog");
    	window.initModality(Modality.APPLICATION_MODAL);
    	window.setMinWidth(600);
        // main window grid pane        
        GridPane grid = new GridPane();
        javafx.geometry.Insets insets = new javafx.geometry.Insets(10, 10, 10, 10);
        grid.setPadding(insets);
        grid.setVgap(8);
        grid.setHgap(10);
        // declare components
        list = new ListView<String>();
        list.setMinSize(600, 400);
        Label detailsLabel = new Label("Recipe Details");
    	// create button
    	Button addButton  = new Button("  Add to Recipe  ");
    	Button moveButton = new Button("Move to Archive");
    	// name table columns
    	TableColumn<Recipe, String> dietColumn = new TableColumn<>("Diet");
    	dietColumn.setMinWidth(100);
    	dietColumn.setCellValueFactory(new PropertyValueFactory<Recipe, String>("diet"));
    	TableColumn<Recipe, String> titleColumn = new TableColumn<>("Title");
    	titleColumn.setMinWidth(500);
    	titleColumn.setCellValueFactory(new PropertyValueFactory<Recipe, String>("title"));    	
    	table = new TableView<>();
    	TableColumn<Recipe, String> dietCol = new TableColumn<>("Diet");
    	dietCol.setMinWidth(100);
    	dietCol.setCellValueFactory(new PropertyValueFactory<Recipe, String>("diet"));
    	TableColumn<Recipe, String> titleCol = new TableColumn<>("Title");
    	titleCol.setMinWidth(500);
    	titleCol.setCellValueFactory(new PropertyValueFactory<Recipe, String>("title"));    	
    	archive = new TableView<>();
////    	table.setItems(recipes);
    	try {
			recipes = loadRecipeTable(table, info, list);
			System.out.println(recipes.get(0).getDiet());
			System.out.println(recipes.get(0).getTitle());
	    	table.setItems(recipes);
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}   	
    	showIngredients();
    	table.setMinSize(600, 100);
    	table.getColumns().addAll(dietColumn, titleColumn);
    	archive = new TableView<>();
    	archive.setItems(getArchive());
    	archive.setMinSize(600, 130);
    	archive.getColumns().addAll(dietCol, titleCol);

        // place components on grid
        GridPane.setConstraints(detailsLabel, 0, 0);
        GridPane.setConstraints(list, 5, 0); // place at column = 10, row = 1
        GridPane.setConstraints(moveButton, 0, 3); // place on left side
        GridPane.setConstraints(addButton, 0, 4); // place on left side
        GridPane.setConstraints(table, 5, 3);
        GridPane.setConstraints(archive, 5, 4);
        grid.getChildren().addAll(detailsLabel, list, archive, table, addButton, moveButton);
        Scene scene = new Scene(grid, 800, 700);
        window.setScene(scene);
        window.show();        
/*    	addButton.setOnAction(e -> );
        moveButton.setOnAction(e -> {
            ObservableList<Recipe> recipeSelected, allRecipes;
            allRecipes = table.getItems();
            recipeSelected = table.getSelectionModel().getSelectedItems();
            recipeSelected.forEach(allRecipes::remove);
//            archive.setItems(recipeSelected);
//            recipes.remove(recipeSelected);
        });
*/
        window.setOnCloseRequest(e -> {
        	// To do any clean up before closing window, like writing archive file
        });
        return recipes;
    }
    
    // used to load table only type and title
    public static ObservableList<Recipe> loadRecipeTable(TableView table, ArrayList<Recipe> info, ListView list) throws IOException, ClassNotFoundException {
    	String fileName = "Fake.bin";
    	ObservableList<Recipe> display = FXCollections.observableArrayList();
    	ArrayList<Recipe> array = new ArrayList<>();
        Recipe recipe_H;
        Recipe recipe_L;
        String ingredients[];
        String directions[];
        
//        System.out.println("here");
        
        FileInputStream fi = new FileInputStream(new File(fileName));
        ObjectInputStream oi = new ObjectInputStream(fi);
        array = (ArrayList) oi.readObject();
        for (int i = 0; i < info.size(); i++) {// && i < array.size(); i++) {
        	Recipe item = new Recipe();
        	recipe_H = info.get(i);
        	item.setDiet(recipe_H.getDiet());        	
//      	    System.out.println(recipe_H.getDiet());
        	item.setTitle(recipe_H.getTitle());
//      	    System.out.println(recipe_H.getTitle());
        	display.add(item);
        }
/*        
        for (Recipe object : list) {
          ingredients = object.getIngredients();
          for (int j = 0; j < ingredients.length; j++) {
           	if (ingredients[j] != null) { 
//          	  System.out.println(ingredients[j]);
       	    }
          }
          directions = object.getDirections();
          for (int j = 0; j < directions.length; j++) {
       	    if (directions[j] != null) { 
//         	  System.out.println(directions[j]);
       	    }
          }
*/            	
//        }
        recipe_H = info.get(0);
        recipe_L = array.get(0);
        recipe_H.setIngredients(recipe_L.getIngredients());
        recipe_H.setDirections(recipe_L.getDirections());
        System.out.println(recipe_H.getUrl());
        System.out.println(recipe_H.getDiet());
        System.out.println(recipe_H.getTitle());
        ingredients = recipe_H.getIngredients();
        for (int j = 0; j < ingredients.length; j++) {
         	if (ingredients[j] != null) {
//        	  System.out.println(ingredients[j]);
        	  list.getItems().add(ingredients[j]);
     	    }
        }
        directions = recipe_H.getDirections();
        for (int j = 0; j < directions.length; j++) {
     	    if (directions[j] != null) { 
//         	  System.out.println(directions[j]);
          	  list.getItems().add(directions[j]);
     	    }
        }            	
//		table.getItems().add(info);
//		table.getItems().add(recipe_H.getDiet());
//		table.getItems().add(recipe_H.getTitle());
//		info.add(recipe_H);

/*        
        for (int i = 0; i < 1; i++) {  //recipes.size() && i < list.size(); i++) {
        	recipe_H = (Recipe)recipes.get(i);
        	recipe_L = list.get(i);
        	ingredients = recipe_L.getIngredients();
            for (int j = 0; j < ingredients.length; j++) {
              	if (ingredients[j] != null) { 
              		recipe_H.setIngredients(ingredients);
            	}
              }
            directions = recipe_L.getDirections();
              for (int j = 0; j < directions.length; j++) {
            	if (directions[j] != null) { 
              		recipe_H.setDirections(directions);
            	}
              }
//              table.getItems().add(recipe_L.getDiet());
//              table.getItems().add(recipe_L.getTitle());

        	System.out.println(recipe_H.getUrl());
        	System.out.print(recipe_H.getDiet() + "  -  ");
        	System.out.println(recipe_H.getTitle() + "\n");
        }
*/
        oi.close();
        fi.close();
		return display;
    }
    
    public static void showIngredients() {
        Document doc;
		String URL = "https://www.olivetomato.com/greek-style-baked-macaroni-and-feta-cheese/";
		doc = Jsoup.parse(URL);
		Elements ingredients = doc.getElementsByClass("wprm-recipe-ingredients");
//	doc = Jsoup.connect(URL).get();
//	String ingredientContainer = "<div.wprm-recipe-ingredient-group/>";
//			String html = "<h3 class="wprm-recipe-header wprm-recipe-ingredients-header wprm-block-text-bold">Ingredients</h3>";
//			String html = "<div><h3>Ingredients</h3>";
//    doc = Jsoup.parseBodyFragment(ingredientContainer);
//	    Element body = doc.body();
//		System.out.println(body);
		System.out.println(ingredients);
    }
    
    // used to load table only type and title
    public static ObservableList<Recipe> getArchive() { // ObservableList<Recipe>
    	ObservableList<Recipe> archives = FXCollections.observableArrayList();
    	// To do: you will need to read recipe from file and store into archive list. archive list is of type Recipe Class
    	Recipe item = new Recipe();
    	item.setDiet("Vegetarian");
        item.setTitle("Roasted red pepper & tomato soup with ricotta");
        archives.add(item);
        item = new Recipe();
        item.setDiet("Vegetarian");
        item.setTitle("Moroccan chickpea, squash & cavolo nero stew");
        archives.add(item);
        item = new Recipe();
        item.setDiet("vegan");
        item.setTitle("Grilled Asparagus and Shiitake Tacos");
        archives.add(item);
        item = new Recipe();
        item.setDiet("Vegan");
        item.setTitle("Easy Roasted Veggies and Tempeh Bowl Recipe");
        archives.add(item);
        item = new Recipe();
        item.setDiet("South Beach");
        item.setTitle("Dessert Chocolate Berry Cups");
        archives.add(item);
        item = new Recipe();
        item.setDiet("Mediterranean");
        item.setTitle("Greek Spinach and Rice � Spanakokorizo");
        archives.add(item);
        item = new Recipe();
        item.setDiet("Mediterranean");
        item.setTitle("Feta and Greek Yogurt Pita Appetizer");
        archives.add(item);
    	return archives;
    }
 }
