package FoodFinder;

import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.scene.control.TableView;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class ShopList {
    public static void display(String[] list) { // this is the list of recipes that you need to grab 
    	ListView<String> listView;
    	Stage window = new Stage();
        window.setTitle("CPT-200 Menu App - Shopping List Dialog");
    	window.initModality(Modality.APPLICATION_MODAL);
    	window.setMinWidth(400);
        // main window grid pane        
        GridPane grid = new GridPane();
        javafx.geometry.Insets insets = new javafx.geometry.Insets(10, 10, 10, 10);
        grid.setPadding(insets);
        grid.setVgap(8);
        grid.setHgap(10);
        // declare components
        listView = new ListView<String>();
        listView.setMinSize(300, 550);
        GridPane.setConstraints(listView, 5, 0); // place at column = 10, row = 1
        grid.getChildren().addAll(listView);
        loadList(listView, list);
        Scene scene = new Scene(grid, 400, 600);
        window.setScene(scene);
        window.show();
        window.setOnCloseRequest(e -> {
        	// To do any clean up before closing window, like writing archive file
        });
    }
    public static void loadList(ListView<String> listView, String[] theList) {
    	listView.getItems().addAll(theList);
    }
}
