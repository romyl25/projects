package FoodFinder;

import java.io.Serializable;

public class Other implements Serializable {
	private static final long serialVersionUID = 1L;
	private String item;
	private String quantity;
	    
    public Other() { } // default constructor
	       
    public String getItem() {
    	return item;
    }

    public void setItem(String item) {
    	this.item = item;
    }
    
    public String getQuantity() {
    	return quantity;
    }

    public void setQuantity(String quantity) {
    	this.quantity = quantity;
    }
}
