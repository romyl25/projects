package prod;
import bus.*;
import data.FileHandler;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.util.StringTokenizer;

import javax.swing.JOptionPane;

public class Humanresourceapp {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
		Employee e1 = new FullTime("Romyl", "Swarnkar", "im.romyl@gmail.com", "(123)456-7890",
				new Address(45, "Sample lane", "St charles", "st charles", "United states",
                "512512"), "222ABCD", EnumType.director, EnumJob.fulltime, 1000000 );
		
		Employee e2 = new FullTime("Rishika", "Swarnkar", "rishika.swornkar@gmail.com", "(234)567-8901",
				new Address(22, "Some street", "St charles", "St charles", "United States",
                "636789"), "222-1111-1111", EnumType.secretary, EnumJob.fulltime,600000 );
		


        DataCollection.add(e1);
        DataCollection.add(e2);
        
        //Creating a report file (will use it at the end of this code to insert employee data.)
        
        File  fileName = new File("report.txt");
        ArrayList aList = DataCollection.getMyList();
        String friend = " ";
        

		
        for(Employee element: DataCollection.getMyList()){
			System.out.println(element);
		}
        
      
        do{
        	String choice;
        	boolean valid = false;	
        	switch(DataCollection.mainMenu()){
        	
        	case 1: //list all
        		for(Employee element: DataCollection.getMyList()){
        			System.out.println(element);
        		}
        		break;
        	case 2://add fulltime
        		Scanner scan = new Scanner(System.in);
        		FullTime e3 = new FullTime();
        		
        		e3.setId(Sequence.getIndex());
        		
        		System.out.println("\n Enter the first name: ");
        		
        		valid = false;
        		do{
					try {
						e3.setFn(scan.next() );
						valid = true;
					} catch (Exception e) {
						System.out.println(e.getMessage());
					}
					}while(!valid);
 
        		
        		System.out.println("\n Enter the last name: ");
        		
        		valid = false;
        		do{
					try {
						e3.setLn(scan.next() );
						valid = true;
					} catch (Exception e) {
						System.out.println(e.getMessage());
					}
					}while(!valid);
        		
        		System.out.println("\n Enter the email: ");
        		
        		valid = false;
        		do{
					try {
						e3.setEmail(scan.next() );
						valid = true;
					} catch (Exception e) {
						System.out.println(e.getMessage());
					}
					}while(!valid);
        		
        		System.out.println("\n Enter the telephone number: ");
        		e3.setTelephone(scan.next());
        		System.out.println("\n Enter the address ");
        		System.out.println("\n\t Enter the street number: ");
        		Address ad = new Address();
        		ad.setStreetNumber(scan.nextInt());
        		System.out.println("\n\t Enter the street name: ");
        		ad.setStreetName(scan.next());
        		System.out.println("\n\t Enter the city name: ");
        		ad.setCity(scan.next());
        		System.out.println("\n\t Enter the province name: ");
        		ad.setProvince(scan.next());
        		System.out.println("\n\t Enter the country name: ");
        		ad.setCountry(scan.next());
        		System.out.println("\n\t Enter the postalcode: ");
        		
        		valid = false;
        		do{
					try {
						ad.setPostalCode(scan.next());
						valid = true;
					} catch (Exception e) {
						System.out.println(e.getMessage());
					}
					}while(!valid);  		
        		
        		e3.setAddress(ad);
        		System.out.println("\n Enter the social security number: ");
        		
        		valid = false;
        		do{
					try {
						e3.setSsn(scan.next());
						valid = true;
					} catch (Exception e) {
						System.out.println(e.getMessage());
					}
					}while(!valid); 
        		
        		
        		System.out.println("\n Enter the job title of the employee: ");
        		System.out.println("\n Choose between the following:");
        		System.out.println("\n 1 - Programmer");
        		System.out.println("\n 2 - Director");
        		System.out.println("\n 3 - Secretary");
        		int job;
        		job = scan.nextInt();
        		if (job == 1){
        			e3.setType(EnumType.programmer);
        		}
        		else if(job == 2){
        			e3.setType(EnumType.director);
        		}
        		else if(job == 3){
        			e3.setType(EnumType.secretary);
        		}
        		else{
        			System.out.println("Please type 1, 2 or 3.");
        		}
        		
        		e3.setJob(EnumJob.fulltime);
        		
        		System.out.println("\n Enter the annual salary: ");	
        		e3.setSalary(scan.nextInt());
        		DataCollection.add(e3);
        		System.out.println("\n The employee was added ");	
        		break;
        		
        		
        	case 3://add part time
        		Scanner scan1 = new Scanner(System.in);
        		PartTime e7 = new PartTime();
        		e7.setId(Sequence.getIndex());
        		System.out.println("\n Enter the first name: ");
        		
        		valid = false;
        		do{
					try {
						e7.setFn(scan1.next() );
						valid = true;
					} catch (Exception e) {
						System.out.println(e.getMessage());
					}
					}while(!valid);
        		
        		System.out.println("\n Enter the last name: ");
        		
        		valid = false;
        		do{
					try {
						e7.setLn(scan1.next() );
						valid = true;
					} catch (Exception e) {
						System.out.println(e.getMessage());
					}
					}while(!valid);
        		
        		System.out.println("\n Enter the email: ");
        		
        		valid = false;
        		do{
					try {
						e7.setEmail(scan1.next() );
						valid = true;
					} catch (Exception e) {
						System.out.println(e.getMessage());
					}
					}while(!valid);
        		
        		System.out.println("\n Enter the telephone number: ");
        		e7.setTelephone(scan1.next());
        		System.out.println("\n Enter the address ");
        		System.out.println("\n\t Enter the street number: ");
        		Address adr = new Address();
        		adr.setStreetNumber(scan1.nextInt());
        		System.out.println("\n\t Enter the street name: ");
        		adr.setStreetName(scan1.next());
        		System.out.println("\n\t Enter the city name: ");
        		adr.setCity(scan1.next());
        		System.out.println("\n\t Enter the province name: ");
        		adr.setProvince(scan1.next());
        		System.out.println("\n\t Enter the country name: ");
        		adr.setCountry(scan1.next());
        		System.out.println("\n\t Enter the postalcode: ");
        		
        		valid = false;
        		do{
					try {
						adr.setPostalCode(scan1.next());
						valid = true;
					} catch (Exception e) {
						System.out.println(e.getMessage());
					}
					}while(!valid);
        		
        		e7.setAddress(adr);
        		
        		System.out.println("\n Enter the social security number: ");
        		
        		valid = false;
        		do{
					try {
						e7.setSsn(scan1.next());
						valid = true;
					} catch (Exception e) {
						System.out.println(e.getMessage());
					}
					}while(!valid);
        		
        		System.out.println("\n Enter the job title of the employee: ");
        		System.out.println("\n Choose between the following:");
        		System.out.println("\n 1 - Trainer");
        		System.out.println("\n 2 - Trainee");
        		int job3;
        		job3 = scan1.nextInt();
        		if (job3 == 1){
        			e7.setType(EnumType.trainer);
        		}
        		else if(job3 == 2){
        			e7.setType(EnumType.trainee);
        		}
        		else{
        			System.out.println("Please type 1 or 2");
        		}
        		System.out.println("\n Enter 1 for FULLTIME job or 2 for PART-Time job: ");
        		int job4;
        		job4 = scan1.nextInt();
        		if (job4 == 1){
        			e7.setJob(EnumJob.fulltime);
        		}
        		else if(job4 == 2){
        			e7.setJob(EnumJob.parttime);
        		}
        		else{
        			System.out.println("Please type 1 or 2 ");
        		}
        		System.out.println("\n Enter the hours worked per week: ");	
        		e7.setHoursWorked(scan1.nextInt());
        		System.out.println("\n Enter the hourly rate: ");	
        		e7.setHourlyRate(scan1.nextDouble());
        		DataCollection.add(e7);
        		System.out.println("\n The employee was added ");
        		
        		
        		break;
        	case 4://Search by id
        		Scanner scan2 = new Scanner(System.in);
        		System.out.println("Please type the id you want to search:");
        		int tempId;
        		tempId = scan2.nextInt();
        		DataCollection.search(tempId);
        		System.out.println(DataCollection.search(tempId));

        		
        		break;
        	case 5://sort by id
        		System.out.println("The employees were sorted successfully.");
        		IdComparator idComparatorObject = new IdComparator();
        		Collections.sort(DataCollection.getMyList(),idComparatorObject);
        		for(Employee element: DataCollection.getMyList()){
        			System.out.println(element);
        		}   		

        		break;
        	case 6://sort by ssn
        		System.out.println("The employees were sorted successfully.");
        		SsnComparator ssnComparatorObject = new SsnComparator();
        		Collections.sort(DataCollection.getMyList(),ssnComparatorObject);
        		for(Employee element: DataCollection.getMyList()){
        			System.out.println(element);
        		}   		
        		
        		
        		break;
        	case 7: //modify
        		Scanner scan3 = new Scanner(System.in);
        		System.out.println("\nPlease type the employee id you want to modify:");
        		int tempId2;
        		tempId2 = scan3.nextInt();
        		System.out.println("\n Enter 1 to make this employee FULLTIME or 2 to make this employee PART-Time: ");
        		int job5;
        		job5 = scan3.nextInt();
        		System.out.println(DataCollection.modify(tempId2, job5));        		
        		break;
        		
        	case 8://read txt file
        		PerformanceLevel[] perfFromTextFile = new PerformanceLevel[2];
        		
        		System.out.println("\n Reading performance level from text file ");
        		FileReader inFile = new FileReader("src/data/PerformanceLevel.txt");
        		BufferedReader reader = new BufferedReader(inFile);
        		StringTokenizer myToken;
        		String record;
        		for(int index=0;index<perfFromTextFile.length;index++){
        			record = reader.readLine();
        			myToken = new StringTokenizer(record, "|");
        			PerformanceLevel aLevel = new PerformanceLevel(Integer.parseInt(myToken.nextToken()), myToken.nextToken(), 
        					Double.parseDouble(myToken.nextToken()) );
        			perfFromTextFile[index] = aLevel;
        			
        		}
        		
        		reader.close();
        		
        		for(int i=0; i< perfFromTextFile.length; i++){
        			System.out.println(perfFromTextFile[i]);
        		}
        		
        		break;
        		
        	case 9:
        		Scanner scan4 = new Scanner(System.in);
        		System.out.println("\n Enter the employee Id you want to set a perfomance level:");
        		int tempId3;
        		tempId3 = scan4.nextInt();
        		DataCollection.search(tempId3);
        		System.out.println(DataCollection.search(tempId3));
        		
        		System.out.println("\n Enter the performance level of this employee (0, 1 or 2): ");
        		int tempPerformance;
        		tempPerformance = scan4.nextInt();
        		DataCollection.setPerfomance(tempId3, tempPerformance);
        		System.out.println("\n The perfomance level was applied ");
        		System.out.println(DataCollection.search(tempId3));
        		break;
        		
        	default:
    			break;
        	}
        
        	// Writing all the employee data in the file.
        	try {
        		FileWriter fw = new FileWriter(fileName);
        		Writer output = new BufferedWriter(fw);
        		int sz = aList.size();
        		for (int i = 0; i <sz; i++) {
        			output.append(aList.get(i).toString() + "\n");
        		}
        		output.close();
        	} catch (Exception e) {
        		JOptionPane.showMessageDialog(null, "I cannot create that file.");
        	}
        	
        	
        }while (true);
        
	}
	
	private static void usingBufferedWritter() {
		// TODO Auto-generated method stub
		
	}

}
