package bus;


public class PartTime extends Employee {

	
	int hoursWorked;
	double hourlyRate;
	
	public int getHoursWorked() {
		return hoursWorked;
	}
	public void setHoursWorked(int hoursWorked) {
		this.hoursWorked = hoursWorked;
	}
	public double getHourlyRate() {
		return hourlyRate;
	}
	public void setHourlyRate(double hourlyRate) {
		this.hourlyRate = hourlyRate;
	}
	public PartTime() {
		super();
	}
	
	public PartTime(String fn, String ln, String email,
			String telephone, Address address, String ssn, EnumType type, EnumJob job, 
			int hoursWorked, double hourlyRate) {
		super(fn, ln, email, telephone, address, ssn, type, job);
		this.hoursWorked = hoursWorked;
		this.hourlyRate = hourlyRate;
	}
	
	//Since part time workers do not get any benefits, they won't be charged $130
	//but as calculated in full time class, payment will be deducted by 10.25% for tax
	
	public double calculPayment()
	{	
		double calculatedSalary;
		
		if(getPerformance()==1){
			calculatedSalary = Math.round(((hoursWorked*hourlyRate*4)*1.015)*0.8975);
		}
		else if (getPerformance()==2){
			calculatedSalary = Math.round(((hoursWorked*hourlyRate*4)*1.01)*0.8975);
		}
		else {
			calculatedSalary = Math.round((hoursWorked*hourlyRate*4)*0.8975);
		}
		return calculatedSalary;
	}
	
	@Override
	public String toString() {
		return "Employee [id=" + id + ", fn=" + fn + ", ln=" + ln
				+ ", email=" + email + ", telephone=" + telephone
				+ ", address=" + address + ", ssn=" + ssn + ", type=" + type
				+ ", job=" + job + ", hoursWorked =" + hoursWorked +", hourlyRate="
				+ hourlyRate + ", payment=" + calculPayment() + "]";
	}
	
	
}
