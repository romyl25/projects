package bus;

public interface IPayable {
	public double calculPayment();
}
