package bus;

import java.util.Comparator;

public class SsnComparator implements Comparator<Employee>{


	public int compare(Employee emp1, Employee emp2){		
		if(emp1.getSsn().equals(emp2.getSsn()))	
			return 0;
		else if(emp1.getSsn().compareTo(emp2.getSsn())>0)
			return 1;			
		else 
			return -1;
		
	}
}

