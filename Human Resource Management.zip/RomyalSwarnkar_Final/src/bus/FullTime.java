package bus;


public class FullTime extends Employee{

	
	double annualSalary;

	public double getSalary() {
	return annualSalary;
	}

	public void setSalary(double annualSalary) {
	this.annualSalary = annualSalary;
	}

	public FullTime() {
		super();
	}

	public FullTime(String fn, String ln, String email, String telephone,
			Address address, String ssn, EnumType type, EnumJob job, double annualSalary) {
		super(fn, ln, email, telephone, address, ssn, type, job);
		this.annualSalary = annualSalary;
	}
	
	
	//Total tax deduction = Federal Tax:3.5% + State Tax: 1.75% + Social Security: 5% = 10.25%,
	//Total Insurance deduction: Health Insurance $100.00 + Dental Insurance: $30.00 = $130.00
	//Therefore amount to be deducted = (100-10.25 of monthly salary)-130 = (monthly salary * 0.8975)-130
	
	//Calculation monthly pay after all deductions
	
	public double calculPayment()
	{
		double calculatedSalary;
		
		if(getPerformance()==1){
			calculatedSalary = Math.round( (((annualSalary/12)*1.015)*0.8975)-130);
		}
		else if (getPerformance()==2){
			calculatedSalary = Math.round( (((annualSalary/12)*1.01)*0.8975)-130);
		}
		else {
			calculatedSalary = Math.round((((annualSalary/12)*0.8975)-130));
		}
		return calculatedSalary;
	}

	@Override
	public String toString() {
		return "Employee [ id=" + id
				+ ", fn=" + fn + ", ln=" + ln + ", email=" + email
				+ ", telephone=" + telephone + ", address=" + address
				+ ", ssn=" + ssn + ", type=" + type +  ", job=" + job + ", annualSalary=" + 
				annualSalary + ", payment=" + calculPayment() + "]";
	}
	
	
}
