package bus;

public enum EnumType {
	director, programmer, secretary, trainer, trainee
}
