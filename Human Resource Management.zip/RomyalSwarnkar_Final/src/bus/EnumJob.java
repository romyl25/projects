package bus;

public enum EnumJob {
	fulltime, parttime
}
